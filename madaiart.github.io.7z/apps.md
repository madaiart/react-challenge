# Apps for improve your English Skills
The follow apps should enhance your english skills. 

## Dictionaries
1. **Oxford English Dictionary**
  Most of the students, researchers, and teachers consider the Oxford dictionary as the best English dictionaries in the world. With precise meanings of the words which are used in day-to-day usage makes it far more useful than any other dictionary.

  > If you purchase the application you have an offline dictionary.

    _This is an online dictionary_
    [Download app ~17MB ](https://play.google.com/store/apps/details?id=com.mobisystems.msdict.embedded.wireless.oxford.dictionaryofenglish&hl=en)
    
    ---

2. **The Merriam - Webster Dictionary (Recommended)**
    After two decades of intensive work to expand into a fully comprehensive dictionary, encompass different fields like medical, business, scientific and technological, Merriam Webster dictionary was first published in the early 1800s.

     _This is an offline dictionary_
    [Download app ~106MB](https://play.google.com/store/apps/details?id=com.merriamwebster)

    ---
   
3. **Cambridge Advanced Learners Dictionary**
    One of the best books for the students preparing for any high-level examination of the English language.

    _I don't test this, Try it!_
    [Download app ~13MB](https://play.google.com/store/apps/details?id=org.cambridge.dictionary.advanced.learners.fourth)

4. [Others Dictionaries](https://digbooks.net/education/dictionary-books)