# Pages with Media in English
Below I present some pages that you can watch free media in English:

## Movies
There are a few pages on internet with free English Movies. _I think that is because of the laws and the culture of citizens._ I select the best pages:
1. **Lunar Movies**


## Anime - Cartoons
1. **KissAnime**

