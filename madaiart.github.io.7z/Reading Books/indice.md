# Readed books
Here is a summary and discussion for the books that I've read.

## This is the list of books {docsify-ignore}

1. [Chemical Secret - Tim vicary](readingBooks/chemicalSecret.md)