# Chemical Secret - Tim Vicary
*There are two ways of committing a crime. You can do it with your eyes open, or you can do it with your eyes clossed.*

## Characters
* **John Ducan** is a biologist. He took the joob at he chemical factory.
* **David Wilson** is a paint factory CEO.
* **Mary Carter** is the best chemist of the factory.
* **Rachel Horsley** is John's wife and a famous sailor.
*  **Christine** is John's sixteen-year-old daughter. She is clever
*  **Andrew** is John's thirteen-year-old son.
*  **Miranda, Jane, Nigel** are Christine friends.
*  **doctor** are the ones who treat the John Ducan illness
*  **Simon MacDonal** Christine fiance
*  **Petter and Sussan** Simon and Christins friends.

## Chapter One - A new start
Jhon Ducan visited the David Wilson's company. He was looking for a job. When he entered to the stay room. He looked to David the CEO of the company and Mary the best chemist that worked here. They had a chat about Jonh's curriculum. David noticed that John stops work as a biologist for 7 years. For that time John explined that he was working with his wife. She was a famous sailor pheraps she had a tragedy in the sea and she died.

Wilson and David continued talking about John's life. Meanwhile John's had thoght that Wilson is a bad person. But surpricely, Wilson hire John's and he will start the next Monday with Mary. His job was about making goverment safe standars papers. That means, he is the responsible for tell the goverment that this factory is safe.

## Chapter two - At home
Jonh Ducan went home at night after the hire meeting. At home there are his two sons. His daugther Christine and his son Adndrew. She was doing homework and he was watching TV. In the dinner, Christine gave the school letter out to his father. The letter was about a skiing holiday and it costed $400. At first she thought that it's imposible to pay that. But before she threw the letter her father saied 'Hold on, Come in I have and interesting history'. Jonh, the fater, speaks out about his hire in the paiting company. He saied that they are gonna be rich.

## Chapter three - Rich man
Jhon Ducan started to work about the waster of the paint facory. The paint produced was a super car paint nor salt or water could damaged. That was the principal reason for the quickly growing of these company. Some day at work Jhon Ducan split some waste products on his leg. He tried to clean up at the moment but the split left a red paintulf mark. For that reason he visited the doctor. The doctor see the mark and ask for it and the activities of the company. Jhon told all about the waste products in the paint factory. Then they discussed about how could affect the wast chemicals to the next people close the river. After the doctors metting, he returned home and had a conversation with his soons. Andrew asked if he could drive the boat. Jhon answered that he are going to teach how drive the sail.

## Chapter four - The seals
A few months later, John invited Mary to his new house. He never invited some one to his old house. Now, He doesn't matter, he felts more confortable with his new possessions. One Sunday Mary went to John's house. That day John decided took them all out in their new boat. they sailed throght the mounth river. The went throught many islands. In one of them they saw a few group of seal families. All of them was impreseed with it.

## Chapter five - The new experiment
John prepared another experiment with rats. He tried to probe if the waste factory products are dangerous for the human life. He had taken the drink to the rats in small quiantities. the ones that drink the water doesn't get illnes. But there was an speciall case for two rats was going to have babies and that will be the last proof. If the babies born in good conditions the waste chemicals will be ok. but if the babies has some mmutation the waste products will be dangerous for the life. That day was the day that the babies was born. Jhon share to Mary his magnifying glass for saw the that especiall ocassion. Mary saw the babies without eyes, without legs and others with many legs and eyes. Afer that they are discussing about the waste chemicals are dangerous for the life.

## Chapter six - The report
Jonh's report was presented to the CEO. Mr. Wilson. The CEO read the report, especially the Jonh's sugesttions. He thought that the report is bad, but not in the stracture, that was incorrect for the suggestions, the factory had had all the money for buy the machines for cleanning the waste products. In adittion if they adquiered these machines all in the factory will get lost the job. And Wilson took seriously to John: "If we build these machines you could lose your big house and your childrens lose everything that they now have.

## Chapter sevent - Christine and Simon
Mary and Jhon had meeting for discuss about his went away for the company because she really knows what are happenig there. And is going to be very dangerous for the live such animals and plants. Jhon ask for some help with his doughter because she is plannig to get married whit some boy that he doesn't upset. He beg her that he want have a litle chat with  his dougther. Then Mary had a conversation with Christine about his fiance. At the finallly they acord to make a big meet with all family including Simon. so the mitting happend and at the end Jhon accept to Simon as the new son in the family. Simon was working as a jurnilst and recently he was working on a new news the seals are mysterious dead.

## Chapter eigth - The wedding day
The seals' deseas was going get worse. Each time more and more seals babies got died. The near people speculate. Someone says that is for the factory, another say this is for the food that they eat. And some researchers begun to investigante the extrain desease. Meanwile the weeding was happening. After the celebration they went to the big John's house. There was a biggest house for the party. All people ejoied and drink a lot for her happiness.

## Chapter nineth - I don't believe you
Some months after the weeding the Jonh's doughter confront his and they started chatting about the waste products in the company. Because the information about the Simon's information is true. The waste products cause the dessease in the seals. Simon was woking on that case for many years and the probe was coming in. Christine asked to his father about the information sended to the local news. She said why CEO Wilson write the critizm letter and you don't write enything about that. You are a scientist. John asnwered saying. The waste products aren't dangerous for the animal I was probing that for many years with my experiments. Also, nobady drinks water from the mounth river.

## Chapter thenth - Greenworld
When John went to Scotland to see Mary, Christine and Simon arrive at John's house. They get the boat and sail for the river. The went upstream the river until cought the waste pipe paint factory. Petter took several strong bags with cement and throw the pipes down. the aim was close that pipe. After that two thing happened. A man ran out the factory and a strong wind move the sails and hits the back Christine head. Then the sail turn down into the water. Simon, Susan and Petter was fighted with the sail trying to push it on the air. Then Simmon saw a body floating downstream the river. That body was Christine she was drowning, Simmon swing so fast as he could but when he cought her. He found her head backwarsds, lifless and she is not breathing. then after a ferous and grand battle with the river they could go to the ground. He countinues blowing in her mouth trying take her to live. Finally she begans to breath. When Chrtistine open her eyes, Simon asked if she is ok. But she was weak and she couldn't speak loudly.

## Chapter eleventh - The Public Enquiry
After Jhon's backs. The Public Enquiry was orginzed to confirm what dangerous are the factoy's waste products. Before the Enquiere The paint factory CEO remembered John that He didn't speak all the true because all people must lost their jobs. In the Enquire de lawer ask some easy questions about the factory like. what activities they do? how care theirself at work? are the chemicals dangerous? and other similars question. But then he asked for the waste products. Jhon's speaks all about the process of the wast products and he allways say that those never will be dangerous for the people because the quantity are few just 2 parts per million. Some periodist ask if some one dring water of the river what will happen?. For that question John say that there isn't dangerous. But the man put over his desk a news about his doughter drowing into the river. John's couldnt believe that because he was traveling to Scotland that time. The lawer ask again if those waste products are dngerous. John was shock, finally he say yes all of them are dangerous.

After the Equiry the paint facory was closed and Jhon gets poor, she only was hopping that his daugther babie was safe.

**the end...**



## Unkown words
1. **greed:** Meaning.
2. **thick:** Meaning.
3. **held out:** Meaning.
4. **suppers:** Meaning.
4. **flat:** Meaning.
4. **bright:** Meaning.
5. **skiing:** Meaning.
5. **untidy:** Meaning.
5. **split:** Meaning.
5. **nasty:** Meaning.
5. **untidy:** Meaning.
5. **tidied:** Meaning.
5. **lit:** Meaning.
5. **nasty:** Meaning.
5. **meant:** Meaning.
5. **lively:** Meaning.
5. **bald:** Meaning.
5. **matter:** Meaning.
5. **field:** Meaning.
5. **supper:** Meaning.
5. **sawage:** Meaning.
5. **frightening:** Meaning.
6. **Enquiry:** Meaning.
7. **shouted:** Meaning.
8. **drowning:** Meaning.
9. **onto:** Meaning.
10. **caught hold:** Meaning.
11. **Hurriedly:** Meaning.
12. **backwards:** Meaning.
13. **shiver:** Meaning.