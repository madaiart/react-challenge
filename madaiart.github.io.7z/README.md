# Hi Fulbright folks...
> This web blog is like a diary of the my life in Fulbright academy. It describes all process in the adventure for learn English Languaje.

## Generals {docsify-ignore}
This web page has two important parts:
1. **Improve skills** In this part you could find information about: [Movile Apps](apps.md), [Movies Web Pages](movies.md) and [Books](books.md). All off them are a free, This is not paied information. Please use in the better way.
2.  **Menu secction** This secction contains the menu with all information that I could retrieve for each english class. In general "here" you can found all of my life in Fulbright. These secction start with Prep Course and will finally with graduation :v:

`If you visited this page with movile device. The MENU is in the footer secction` 
