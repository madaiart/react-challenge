<!-- Nav baar -->
* **Improve skills**

  * [:iphone:   Apps](apps.md)
  * [:tv:    Movies](movies.md)
  * [:book:    Books](books.md)
  * [:radio:    Podcast](podcast.md)
  * [:coffee:   Web](webpages.md)
