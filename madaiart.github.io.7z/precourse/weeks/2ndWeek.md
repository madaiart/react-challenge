# SECOND SCHOOL WEEK
## 6th School day
_Monday, 15 April 2019_

### Class Activities
The class started reviewing the Friday homework. At the same time we was chatting about __What do you do every day?__
After these chat. The teacher say who wants to share with te class the information about your classmate. Some mates share with us the partner information. The teacher catch some mistakes that we do when speak. Some of these errors are the following:
1. She returns **at** home :x:
- She **goes** home :heavy_check_mark:
  
2. Her house is **near to** Alameda :x:
- Her ouse is (**next to, close to, near**) Alameda :heavy_check_mark:

3. Others corrections are related with Delexial Verbs.
> Here there is a full information about Delexical Verbs like **go, do, make, have, give** and others. Please see these links
[curso-ingles.com](https://www.curso-ingles.com/en/learn/courses/advanced-level/collocations-and-expressions/delexical-verbs) and
[British Council](https://learnenglish.britishcouncil.org/english-grammar/delexical-verbs-have-take-make-and-give).

#### Countable and Uncountable nouns
Then we reviewed about countable and uncountable nouns. The principal example here was:

I have three advices for my studen :x:
I have (**have, some, a lot of**) advice for my student :heavy_check_mark:

##### Uncountable nouns
1. Singular
2. No numbers before
3. No are *(to be)*

### Homework
- [X] Write 10 noncountable nouns that there isn't in the book.
  
________________________________________
## 7th School day
_Tuesday, 16 April 2019_

<!-- > This day I forget my Card ID and the guard couldn't permit me enter to the Academy :cry: -->
:clock530:
*I was absent this day*

### Class Activities
Read the second secction and aswer the sentences.
### Homework

- [X] :ok_hand: Study the page 8|70 of the book.
________________________________________
## 8th School day
_Wednesday, 17 April 2019_

### Class Activities
:raining: Today was gonna be rainig but. Something scares the clouds. :thinking:

Starting the class we continued doing the last work in class. That task was get the meaning of somewords that are present in the second text of reading section.
Finished that task. We shared and compare the findings. Then the teacher gave us a litlte task. That task was ask to other friend about his skills and weakness. For example:

* He is goot at driving cars (neative).
* He is a few lazy (positive).
* He is not so good at sports (negative).
  
That was all for today.

### Homework
- [X] Answer the sentences about the second reading section
- [x] Review the page nine of the book **few a litle things**

________________________________________
## 9th School day
_Thursday, 18 April 2019_

### Class Activities
We practiced the **few little many much a lot of some a few and a many** words in the text book 
we did the activities 6,7,8,9.

### Homework
- [ ] Write 5 sentences with few and 5 with little with each respectives answers.

