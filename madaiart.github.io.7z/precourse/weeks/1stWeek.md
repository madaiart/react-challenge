# FIRST SCHOOL WEEK
## 1st School day
_Monday, 8 April 2019_

### Class Activities
Begining the class the teacher present yourself. Her name is Sofia Falconí Sachs.
After the presentation. She share with us all material:
1. The Prep Course Book
1. The Card ID
1. The Syllabus

She began explaning about the syllabus sheet. All the strong rules that have the Fulbright academy are important for not to lose the level. The only exeption rule is:

> :smile:    She permits that we could arrive only 5 minutes later.  

After that, she give us a litle task. The task was write in a small piece of paper whit the next information.

### Homeworks

1. Read the fulbright information :persevere:
    * [X] [Prep Course Welcome](https://www.fulbright.org.ec/imagenes/CURRENT_STUDENTS_%20WEB_%20PAGE/PREP_COURSE_WELCOME_TO_FULBRIGHT/WelcomeFulbrightCycle22019.pdf)
    * [X] [Honor Code](https://www.fulbright.org.ec/imagenes/CURRENT_STUDENTS_%20WEB_%20PAGE/UPDATED_HONOR_CODE/HonorCode2019.pdf)
    * [X] [Letter to Students](https://www.fulbright.org.ec/imagenes/CURRENT_STUDENTS_%20WEB_%20PAGE/UPDATED_HONOR_CODE/LettertoStudents2019.pdf)
________________________________________
## 2nd School day
_Tuesday, 9 April 2019_

### Class Activities
:sound: This day we started chating about ourselves with our partners. After that, we wrote some information about the clasmate in a piece of paper. 

:mag: For the second activity, we wrote a name of **famous person**. Sofia, the teacher, give up the papers and then sort all of them. After, we received another famous person. This was a game and consisted in get correct the name of the person that we are using **Yes/Not Questions**.

### Homeworks
- [X] In the book :notebook: review the information about Present Simple. This information is in the **48,49 pages.**

________________________________________
## 3rd School day
_Wednesday, 10 April 2019_
### Class Activities
The activities in class were a simple review of present simple tense. In general the present simple tense are used for:
* Facts / General Facts
* Rutins / Hobbies / Customs
* Non Actions Verbs like feelings
* Plan events in future
* Abstracts concepts. E.g lobe is happines | Or maybe opinions

#### Structure of Simple present
The simple present is formed by:

> S + V (base form) + O

**Note** Simple present, third person singular
1. **he, she, it:** in the third person singular the verb **always ends in -s**. For example: He want**s**. She need**s**.
2. Negative and question forms use DOES (the thrid person of the auxiliary 'DO') **+** the infinite of the verb. For Example: He want**s**. **Does** he want? He **does** not want or She **does**n't want.
3. Verbs ending in **-y**: Ther third person changes the **-y** to **-ies**. For exmaple: fly => fli**es**, cry => cri**es**.
   > *Exception*: If there is a vowel before the **-y**. For example: pla**y** => play**s**, pra**y** => pray**s**
4. Add **-es** to verbs ending in: **-ss, -x, -sh, -ch**
5. Others 
   1. be => am, is, are
   2. do => does
   3. have => has

> After a few discussion we did the 53,54,55 tasks in the book.

________________________________________
## 4th School day
_Thursday, 11 April 2019_
### Class Activities
1. What is an **auxiliary verb**? It is a word that modify the meaning of the verb.
2. The structure of the questions is:
   > **Do/Does** + S + V(base form) + O.
3. Resolve the exercise 56; practice the short answers.
4. Read the first section of the lecture. Read the first lecture and aswer the questions.

### Homeworks
- [X] For that class the reading section we didn't finished. Sofia tell us that these task will be finish the next day.

________________________________________
## 5th School day
_Friday, 12 April 2019_
### Class Activities
After finish the task. The teacher told us that we had the oportunity for pick up one book for the Fulbright's library.
> We should bring the book every day.

**Adjetives a or an**
1. We use **a** if the next sound **isn't** like a vowel or if the next word starts with a consonant. For example: **a ho**tel, **a chief**, a **pencil**, **a u**niversity, etc.
2. We use **an** if the next sound **is** like a vowel or if the next word starts with a vowel. For example: **an ho**ur, **an umbrella**, an **apple**, etc.  

> The pronunciation of these words are linked like an umbrella. it sounds *anumbrella*