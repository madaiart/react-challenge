## 14th School day
_Monday, 6 May 2019_

### Class Activities
At the beggining the class we have a short exam about plurals, nouns (countable and uncontable), and quantifiers.  
Afer that we have the review of the last homework.
Finally, We have a listen activity.

### Homework
- [ ] Study the charts of pages 64, 65 and 66. We gonna finsh the present simple.
________________________________________

## 15th School day
_Tuesday, 7 May 2019_

### Class Activities


### Homework

________________________________________

## 16th School day
_Wednesday, 8 May 2019_

### Class Activities


### Homework

________________________________________

## 17th School day
_Thurday, 9 May 2019_

### Class Activities


### Homework

________________________________________


## 18th School day
_Thurday, 9 May 2019_

### Class Activities


### Homework

________________________________________