## 10th School day
_Monday, 22 April 2019_

### Class Activities


### Homework

________________________________________

## 11th School day
_Tuesday, 23 April 2019_

### Class Activities


### Homework

________________________________________

## 12th School day
_Wednesday, 24 April 2019_

### Class Activities
- Work in book and listening section
<!-- - TODO put the record audio -->

### Homework

________________________________________

## 13th School day
_Thurday, 25 April 2019_

### Class Activities


### Homework

________________________________________