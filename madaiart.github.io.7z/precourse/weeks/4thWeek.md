## 10th School day
_Monday, 29 April 2019_

### Class Activities
- Who do you admire most in the world?
- I admire __________  most in the world.
- **Allways adjetive is before the noun.** exept woth to be verb.

### Homework
- [X] Study writing page 7 and do the exerise 3 and 4.
________________________________________

## 11th School day
_Tuesday, 30 April 2019_

### Class Activities
- Using *Whose* for asking for things that belows
  
  **Example:**
  - Whose marker is this/that?
    - Sofia's
    - Her marker
    - Hers
  - Whose markers are these/those
    - There're


|Pronoun|Possesive noun*|Possessive adjetive|Posessiceve pronoun|Reflexive propoun|
|-------|--------------|-------------------|-------------------|-----------------|
|  I    |     Whit     | my                |      mine         |  myself         |
|  You  |      's      |   your            |   yours           |   yourself      |
|  He   |              |       his         |    his            |  hiself         |
|  She  |              |  her              |    hers           |  herself        |
|  It   |              |     -             |    its            |  itself         |
|  We   |              |        our        |       ours        |  ourself        |
|  They |              |           their   |           theirs  |  theriself      |
|--------------------------------------------------------------------------------|
*Like Sofias' or Paul's
Remember the diferent pronunciation with: **Whose is** and **Who's**


### Homework

________________________________________

## 12th School day
_Wednesday, 1 May 2019_

### NO CLASES - Work day holiday!
________________________________________

## 13th School day
_Thurday, 2 May 2019_

### Class Activities
- Review about the present progresive
  The structure is:

  **S + V(to be)+ Verb in Gerund+ O**

  - Activities made in class was 42, 43, 44, 45, 46, 47, 48, 49.

  Remeber that Only the actión verbs should be gerunds, non actions verbs never put in gerund.

### Homework

- [X] In the book make the task 61, 62, 63, 64, 65.

________________________________________