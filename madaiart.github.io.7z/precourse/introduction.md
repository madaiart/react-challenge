# The adventure begins
Once upon a time, There was a young man that want to improve his English skylls. He started his journey in Ecuador, this is a **small country** located in Soud America. The man taked his first exam in the Fulbright academy hopping the best results. 

## Disappointed and persevere {docsify-ignore}
:disappointed_relieved: :persevere:

The next week after the test, he recived an email with the results of the ubication exam. That information wasn't pleasant . But he wanted to improve his English. For that reason he decided going to the **Prep Course**. The principal reason was known his weaknesses.   

This journey start with the first week:
> [First Week](weeks/1stWeek.md)