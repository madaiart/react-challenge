<!-- _sidebar.md -->

- [*Home*](/)

- [:bird: **Pre Course**](precourse/introduction.md "Pre course fulbright - Cicle III April - July")
    * *School Days*
        * [1st Week](precourse/weeks/1stWeek.md "Fist school week")
        * [2nd Week](precourse/weeks/2ndWeek.md "Second school week")
        * [3rd Week](precourse/weeks/3rdWeek.md "Third school week")
        * [4th Week](precourse/weeks/4thWeek.md "Fourth school week")
  
- [:books: **Reading Books**](readingBooks/indice.md "This all books that I have read")
  - [Chemical Secret - Tim Vicary](readingBooks/1_chemicalSecret.md)